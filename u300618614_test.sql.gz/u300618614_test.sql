-- MySQL dump 10.16  Distrib 10.1.20-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.1.23-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `annotazioni`
--

DROP TABLE IF EXISTS `annotazioni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `annotazioni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `versi_id` int(11) NOT NULL,
  `combinazioni_id` int(11) NOT NULL,
  `categoriaCambiamento_id` int(11) NOT NULL DEFAULT '0',
  `rima_id` int(11) NOT NULL,
  `commento` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`,`versi_id`,`combinazioni_id`,`categoriaCambiamento_id`,`rima_id`),
  KEY `fk_annotazione_categoriaCambiamento1_idx` (`categoriaCambiamento_id`),
  KEY `fk_annotazione_rima1_idx` (`rima_id`),
  KEY `fk_annotazione_combinazioni1_idx` (`combinazioni_id`),
  KEY `fk_annotazione_versi1_idx` (`versi_id`)
) ENGINE=MyISAM AUTO_INCREMENT=247 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annotazioni`
--

/*!40000 ALTER TABLE `annotazioni` DISABLE KEYS */;
INSERT INTO `annotazioni` VALUES (123,121,1,0,2,''),(124,122,3,0,2,''),(125,123,1,0,2,''),(126,124,1,0,2,''),(127,125,3,0,2,''),(128,126,3,0,2,''),(129,127,1,0,2,''),(130,128,1,5,2,''),(131,129,1,0,2,''),(132,130,2,0,2,''),(133,131,1,0,2,''),(134,132,1,0,2,''),(122,120,1,0,1,''),(121,119,3,0,2,''),(120,118,3,1,2,''),(116,114,1,6,2,''),(117,115,1,0,2,''),(118,116,1,0,2,'<i>venir</i> è anticipazione del verso successivo <i>venire, e coronarmi de le foglie</i>'),(119,117,1,0,2,'Nei codici Riccardiano e Chigiano <i>venirè</i> anticipato al verso precedente'),(7,1,3,5,2,'La variante <i>coperte</i> del codice Chigiano risulta tra le più significative dell’insieme delle varianti. Si tratta di variante adiafora non attestata in nessuno dei codici dell’antica vulgata né attribuibile a fenomeni di anticipazione o posticipazione. Plausibile l’influenza dei Commenti alla Commedia precedenti il Boccaccio: <i>Coperta</i> è infatti attestato nel commento di Jacopo Alighieri (<i>de raggi del sole coperta la vide</i>) e nell’Ottimo Commento (<i>la vide coperta delli raggi sel sole</i>)'),(8,2,1,0,2,''),(9,4,3,1,2,''),(10,5,1,0,2,'Si tratta probabilmente di una ripresa erronea del precedente <i>Con la</i> (Inf. I, 47: <i>con la test’alta e con rabbiosa fame</i>).'),(11,6,3,3,1,'Inf I, 50-52: <i>sembiava carca ne la sua magrezza/ e molte genti fé già viver grame,/questa mi porse tanto di gravezza</i>. \nNel codice Chigiano <i>grameça</i> del verso 50 è probabile errore di anticipazione, influenzato da <i>grame</i> del verso seguente.'),(12,7,3,3,1,'<i>grameça</i> nel codice Chigano è probabilmente influenzato dalla lezione <i>grameça</i> erroneamente riporatata dallo stesso codice ad Inf. I, 50.'),(13,8,3,0,2,''),(14,9,3,5,2,''),(15,10,3,0,2,''),(16,11,3,0,1,''),(17,12,3,4,2,''),(18,13,1,0,2,''),(19,14,1,0,1,''),(20,16,2,3,2,'<i>alta</i> è probabilmente influenzato da <i>alto</i> di Inf. II, 17 […] <i>pensando l\'alto effetto</i>'),(21,17,1,0,2,''),(22,18,1,4,2,''),(23,21,1,1,2,'<i>da quel</i> (codice Toledano) in luogo di <i>di quel</i>  è attestato in buona parte della tradizione.'),(24,22,1,0,2,''),(25,23,1,0,2,''),(26,24,1,5,2,'<i>Alto</i> è aggettivo molto frequente nella Commedia e, in particolare, nel canto II dell’Inferno (cfr. Inf. II, 7: <i>alto ingegno</i>; Inf. II, 12: <i>alto passo</i>; Inf. II, 17: <i>alto effecto</i>).'),(27,25,1,0,2,'Solo la lezione del codice Toledano è presente nell\'antica vulgata, non quella dei codici Riccardiano e Chigiano .'),(28,26,1,5,1,'La variante <i>poderose</i> è discussa nel commento di Benvenuto. Non attestata nell’antica vulgata, potrebbe essere influenzato dal  precedente <i>potenza</i> di Inf I, 89.'),(29,27,1,0,2,''),(30,28,1,0,2,''),(31,29,1,5,2,'<i>Sono</i> è variante non attestata nei codici dell\'antica vulgata, errore di probabile natura paleografica forse influenzato dal precedente <i>sonno</i> di Inf. IV, 1: <i>Ruppemi l\'alto sonno ne la testa</i>.'),(32,30,1,0,2,''),(33,31,1,4,2,''),(34,32,1,0,2,'Eco interna: <i>nel primo cinghio che l\'abisso cigne</i>'),(35,33,1,0,2,''),(36,34,3,0,1,''),(37,35,3,0,2,''),(38,36,1,0,2,''),(39,37,1,0,2,''),(40,38,1,0,2,''),(41,39,1,0,2,''),(42,40,1,0,2,''),(43,41,1,2,2,''),(44,42,3,0,2,''),(45,43,3,0,2,''),(46,44,3,0,1,'<i>Corrotta</i> è probabilmente influenzato dal precedente <i>A vizio di lussuria fu sì rottai</i>.'),(47,45,1,0,2,'è presente nella tradizione la lezione di Chig, non la lezione di To e Ri'),(48,46,1,0,2,''),(49,47,1,0,2,''),(50,48,1,5,2,''),(51,49,1,0,2,'è presente nella tradizione la lezione di Chig, non la lezione di To e Ri'),(52,50,1,0,2,''),(53,51,3,3,2,'<i>Sospiri</i> è anticpazione di Inf. V, 118 <i>[…]dolci sospiri</i>'),(54,52,3,0,2,'eco del precedente <i>Quali colombe dal disio chiamate</i> (Inf. V, 82)'),(55,53,1,5,2,''),(56,54,1,4,2,''),(57,55,1,0,2,''),(58,56,3,4,2,'<i>Tenendo</i> è probabilmnete influenzato da due gerundi precedenti: Inf. XXIX, 17-18 lo <i>duca, già faccendo la risposta,/ e soggiugnendo […]</i>.'),(59,57,1,0,2,''),(60,58,1,0,2,''),(61,59,3,4,2,''),(62,60,3,0,2,''),(63,61,1,0,2,''),(64,62,1,0,2,''),(65,63,1,0,2,''),(66,64,1,0,2,''),(67,65,3,0,2,''),(68,66,1,0,2,''),(69,67,1,0,2,''),(70,68,1,0,2,''),(71,69,1,0,1,''),(72,70,1,0,2,''),(73,71,3,0,2,''),(74,72,1,0,1,''),(75,73,1,0,2,''),(76,74,1,0,2,''),(77,75,3,0,2,''),(78,76,1,0,2,''),(79,77,1,0,2,''),(80,78,3,5,2,'<i>Dissello</i>: probabilmente influenzato da <i>diss’io</i> di Inf. XXXII, 109: <i>Omai, diss’io, non vo’ che più favelle</i>.'),(81,79,1,0,2,''),(82,80,1,2,2,''),(83,81,1,0,2,''),(84,82,3,0,2,''),(85,83,3,5,1,'<i>fame</i> è sinonimo di voglia:Inf,XXXIII, 58-59 <i>ambo le man per lo dolor mi morsi; /ed ei pensando ch’io’l fessi per voglia</i>.'),(86,84,1,0,2,''),(87,85,1,0,2,''),(88,86,0,6,2,''),(89,87,1,4,2,''),(90,88,1,5,2,''),(91,89,1,0,2,''),(92,90,3,3,1,'<i>Congiunto</i> è eco del precedente rimante <i>giunto</i>: <i>E se’ or sotto l’emisperio giunto</i> (Inf. XXXIV, 112)'),(93,91,1,0,2,''),(94,92,1,0,2,''),(95,93,3,0,2,''),(96,94,1,0,2,''),(97,95,1,0,2,''),(98,96,3,0,2,''),(99,97,3,0,2,''),(100,98,1,1,3,''),(101,99,1,0,2,''),(102,100,1,1,3,''),(103,101,1,0,2,''),(104,102,3,0,2,''),(105,103,1,0,2,''),(106,104,1,0,2,''),(107,105,1,0,2,''),(108,106,1,0,2,''),(109,107,1,4,2,''),(110,108,1,5,2,'<i>Io era già da quell’ombre partito, / e seguitava l’orme del mio duca, / quando di retro a me, drizzando ’l dito, / una gridò: \"Ve’ che non par che luca\"</i>. Nel codice riccardiano e nel successivo codice chigiano Boccaccio anticipa il soggetto una al verso precedente sostituendolo con l’avverbio forte al verso successivo: <i>quando una retro ad me driçando il dito / forte grido ve che non par che luca</i>. Forse eco di Purgatorio 23, 41-42 <i>volse a me li occhi un’ombra e guardò fiso; / poi gridò forte: \"Qual grazia m’è questa?”</i>.'),(111,109,1,0,2,''),(112,110,3,0,2,''),(113,111,3,0,2,''),(114,112,1,0,2,''),(115,113,3,0,2,''),(135,133,3,4,2,''),(136,134,1,0,2,''),(137,135,1,0,2,''),(138,136,1,5,2,''),(139,137,1,0,2,''),(140,138,1,2,2,''),(141,139,1,0,2,'<i>Come</i> è eco di Par. IV, 85  <i>come tenne Lorenzo in su la grada</i>'),(142,140,1,4,2,''),(143,141,1,0,2,''),(144,142,1,0,1,''),(145,143,1,0,2,''),(146,144,1,0,2,''),(147,145,1,0,2,''),(148,146,1,0,2,''),(149,147,1,0,2,''),(150,148,1,0,2,''),(151,149,1,0,2,''),(152,151,1,1,2,''),(153,153,3,4,2,''),(154,155,1,5,2,''),(155,159,1,5,2,''),(156,163,3,3,2,'<i>Giudicio [di Dio]</i> è probabile anticipazione di Inf. VII, 83: <i>[…] giudicio di coste</i>. Inoltre si veda Inf. XX, 30: \"che al giudico divin passion comporta\",  nel Chigiano (e in altri codici dell’antica vulgata) <i>ch’al giudicio di dio passion comporta</i>'),(157,166,1,5,2,''),(158,171,3,5,2,''),(159,172,1,2,2,'Il verso presuppone dieresi “fecesi Flegïàs ne l’ira accolta” che non viene accolta dal Boccaccio  Cfr. PETROCCHI, <i>Alighieri. La Commedia. Inferno</i>, p. 129'),(160,174,1,5,2,''),(161,177,1,3,2,'<i>Grave</i> è eco del primo emistichio del verso: \"Coi gravi cittadin […]\"'),(162,179,1,3,2,'<i>Terra</i> (poi corretto a margine) è eco del verso precendente: Inf. VII, 77 “che vallan quella terra sconsolata”.'),(163,181,1,2,2,''),(164,184,3,4,2,''),(165,186,1,5,2,''),(166,190,1,2,2,''),(167,192,1,3,2,'<i>V’aperse</i> è lezione probabilmente influenzata dal  successivo \"non v’ebbe alcun ritegno\" dello stesso verso.'),(168,194,3,3,1,'<i>Avaro</i> è eco di <i>varo</i> di Inf. IX, 115: […] il loco varo.'),(169,198,1,1,2,''),(170,151,1,1,2,''),(171,153,3,4,2,''),(172,155,1,5,2,''),(173,159,1,5,2,''),(174,163,3,3,2,'<i>Giudicio [di Dio]</i> è probabile anticipazione di Inf. VII, 83: <i>[…] giudicio di coste</i>. Inoltre si veda Inf. XX, 30: \"che al giudico divin passion comporta\",  nel Chigiano (e in altri codici dell’antica vulgata) <i>ch’al giudicio di dio passion comporta</i>'),(175,166,1,5,2,''),(176,171,3,5,2,''),(177,172,1,2,2,'Il verso presuppone dieresi “fecesi Flegïàs ne l’ira accolta” che non viene accolta dal Boccaccio  Cfr. PETROCCHI, <i>Alighieri. La Commedia. Inferno</i>, p. 129'),(178,174,1,5,2,''),(179,177,1,3,2,'<i>Grave</i> è eco del primo emistichio del verso: \"Coi gravi cittadin […]\"'),(180,179,1,3,2,'<i>Terra</i> (poi corretto a margine) è eco del verso precendente: Inf. VII, 77 “che vallan quella terra sconsolata”.'),(181,181,1,2,2,''),(182,184,3,4,2,''),(183,186,1,5,2,''),(184,190,1,2,2,''),(185,192,1,3,2,'<i>V’aperse</i> è lezione probabilmente influenzata dal  successivo \"non v’ebbe alcun ritegno\" dello stesso verso.'),(186,194,3,3,1,'<i>Avaro</i> è eco di <i>varo</i> di Inf. IX, 115: […] il loco varo.'),(187,198,1,1,2,''),(188,151,1,1,2,''),(189,152,1,0,2,''),(190,153,3,4,2,''),(191,154,1,0,2,''),(192,155,1,5,2,''),(193,156,1,0,2,'Sul cambio di genere si veda Il Petrocchi : \" Il genere maschile, dopo il femminile della terzina 37-39, è imposto dal fatto che l\'ombra s\'è fatta riconoscere per quella di un uomo: prima ch\'io disfatto\" (Cfr. PETROCCHI, Alighieri. La Commedia. Inferno, p.100.'),(194,157,1,0,2,''),(195,158,3,0,2,''),(196,159,1,5,2,''),(197,160,3,0,2,''),(198,161,1,0,2,''),(199,162,1,0,2,''),(200,163,3,3,2,'<i>Giudicio [di Dio]</i> è probabile anticipazione di Inf. VII, 83: <i>[…] giudicio di coste</i>. Inoltre si veda Inf. XX, 30: \"che al giudico divin passion comporta\",  nel Chigiano (e in altri codici dell’antica vulgata) <i>ch’al giudicio di dio passion comporta</i>'),(201,164,1,0,2,''),(202,165,1,0,2,''),(203,166,1,5,2,''),(204,167,1,0,2,''),(205,168,1,0,2,'<i>Una palude va</i> viene corretto in glossa in To: Una palude fa. Boccaccio accoglie quest’ultima lezione nel testo delle Esposizioni. Cfr. Petrocchi, <i>Alighieri, Introduzione</i>, p. 173.'),(206,169,1,0,1,''),(207,170,1,0,2,''),(208,171,3,5,2,''),(209,172,1,2,2,'Il verso presuppone dieresi “fecesi Flegïàs ne l’ira accolta” che non viene accolta dal Boccaccio  Cfr. PETROCCHI, <i>Alighieri. La Commedia. Inferno</i>, p. 129'),(210,173,3,0,2,''),(211,174,1,5,2,''),(212,175,2,0,2,''),(213,176,1,0,2,''),(214,177,1,3,2,'<i>Grave</i> è eco del primo emistichio del verso: \"Coi gravi cittadin […]\"'),(215,178,1,0,2,''),(216,179,1,3,2,'<i>Terra</i> (poi corretto a margine) è eco del verso precendente: Inf. VII, 77 “che vallan quella terra sconsolata”.'),(217,180,1,0,2,''),(218,181,1,2,2,''),(219,182,1,0,2,''),(220,183,1,0,2,''),(221,184,3,4,2,''),(222,185,1,0,1,'Dalla lezione <i>trine</i> del gruppo Vaticano attestata in To, torna nella coppia Ri-Chig a <i>crine</i>, attestato in numerosi manoscritti e influenzato da <i>crine</i> del precedente verso 41 (\"serpentelli e ceraste avien per crine\"). Cfr. PETROCCHI, <i>Alighieri. La Commedia. Inferno</i>, p. 148 e PETROCCHI,<i> Introduzione<i>, p.104.'),(223,186,1,5,2,''),(224,187,1,0,2,''),(225,188,1,0,1,''),(226,189,1,0,2,''),(227,190,1,2,2,''),(228,191,1,0,2,''),(229,192,1,3,2,'<i>V’aperse</i> è lezione probabilmente influenzata dal  successivo \"non v’ebbe alcun ritegno\" dello stesso verso.'),(230,193,1,0,2,''),(231,194,3,3,1,'<i>Avaro</i> è eco di <i>varo</i> di Inf. IX, 115: […] il loco varo.'),(232,195,1,0,2,''),(233,196,1,0,2,''),(234,197,1,0,2,''),(235,198,1,1,2,''),(236,200,1,0,2,''),(237,201,3,0,2,''),(238,202,2,0,2,'<i>Disse</i> è lezione probabilmente influenzata dal successivo dicesti di Inf. X, 68: \"dicesti elli ebbe […]\". Probabile anche l’eco del precedente </i>decto</i> messo a testo dai tre codici del Boccaccio (Inf. X, 65: <i>mavean di costui gia decto il nome</i> in To, Ri e Chig contro il \"m’avean di costui già letto il nome\" attestato dalla quasi totalità della tradizione).'),(239,203,1,0,2,''),(240,204,1,0,2,''),(241,205,1,0,2,''),(242,206,2,0,2,''),(243,207,1,0,2,''),(244,208,1,0,2,''),(245,406,1,0,2,''),(246,407,1,0,2,'');
/*!40000 ALTER TABLE `annotazioni` ENABLE KEYS */;

--
-- Table structure for table `cantica`
--

DROP TABLE IF EXISTS `cantica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cantica` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `cantica` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cantica`
--

/*!40000 ALTER TABLE `cantica` DISABLE KEYS */;
INSERT INTO `cantica` VALUES (1,'Inf'),(2,'Purg'),(3,'Par');
/*!40000 ALTER TABLE `cantica` ENABLE KEYS */;

--
-- Table structure for table `canto`
--

DROP TABLE IF EXISTS `canto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `canto` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `canto` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `numero` decimal(5,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `canto`
--

/*!40000 ALTER TABLE `canto` DISABLE KEYS */;
INSERT INTO `canto` VALUES (1,'I',1.01),(2,'II',1.02),(3,'III',1.03),(4,'IV',1.04),(5,'V',1.05),(6,'VI',1.06),(7,'VII',1.07),(8,'VIII',1.08),(9,'IX',1.09),(10,'X',1.10),(11,'XI',1.11),(12,'XII',1.12),(13,'XIII',1.13),(14,'XIV',1.14),(15,'XV',1.15),(16,'XVI',1.16),(17,'XVII',1.17),(18,'XVIII',1.18),(19,'XIX',1.19),(20,'XX',1.20),(21,'XXI',1.21),(22,'XXII',1.22),(23,'XXIII',1.23),(24,'XXIV',1.24),(25,'XXV',1.25),(26,'XXVI',1.26),(27,'XXVII',1.27),(28,'XXVIII',1.28),(29,'XXIX',1.29),(30,'XXX',1.30),(31,'XXXI',1.31),(32,'XXXII',1.32),(33,'XXXIII',1.33),(34,'XXXIV',1.34),(35,'I',2.01),(36,'II',2.02),(37,'III',2.03),(38,'IV',2.04),(39,'V',2.05),(40,'VI',2.06),(41,'VII',2.07),(42,'VIII',2.08),(43,'XIX',2.09),(44,'X',2.10),(45,'XI',2.11),(46,'XII',2.12),(47,'XIII',2.13),(48,'XIV',2.14),(49,'XV',2.15),(50,'XVI',2.16),(51,'XVII',2.17),(52,'XVIII',2.18),(53,'XIX',2.19),(54,'XX',2.20),(55,'XXI',2.21),(56,'XXII',2.22),(57,'XXIII',2.23),(58,'XXIV',2.24),(59,'XXV',2.25),(60,'XXVI',2.26),(61,'XXVII',2.27),(62,'XXVIII',2.28),(63,'XXIX',2.29),(64,'XXX',2.30),(65,'XXXI',2.31),(66,'XXXII',2.32),(67,'XXXIII',2.33),(68,'I',3.01),(69,'II',3.02),(70,'III',3.03),(71,'IV',3.04),(72,'V',3.05),(73,'VI',3.06),(74,'VII',3.07),(75,'VIII',3.08),(76,'IX',3.09),(77,'X',3.10),(78,'XI',3.11),(79,'XII',3.12),(80,'XIII',3.13),(81,'XIV',3.14),(82,'XV',3.15),(83,'XVI',3.16),(84,'XVII',3.17),(85,'XVIII',3.18),(86,'XIX',3.19),(87,'XX',3.20),(88,'XXI',3.21),(89,'XXII',3.22),(90,'XXIII',3.23),(91,'XXIV',3.24),(92,'XXV',3.25),(93,'XXVI',3.26),(94,'XXVII',3.27),(95,'XXVIII',3.28),(96,'XXIX',3.29),(97,'XXX',3.30),(98,'XXXI',3.31),(99,'XXXII',3.32),(100,'XXXIII',3.33);
/*!40000 ALTER TABLE `canto` ENABLE KEYS */;

--
-- Table structure for table `categoriaCambiamento`
--

DROP TABLE IF EXISTS `categoriaCambiamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoriaCambiamento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoriaCambiamento`
--

/*!40000 ALTER TABLE `categoriaCambiamento` DISABLE KEYS */;
INSERT INTO `categoriaCambiamento` VALUES (1,'omissione / aggiunta'),(2,'inversione'),(3,'eco / anticipazione'),(0,''),(4,'morfologica'),(5,'lessicale');
/*!40000 ALTER TABLE `categoriaCambiamento` ENABLE KEYS */;

--
-- Table structure for table `combinazioni`
--

DROP TABLE IF EXISTS `combinazioni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `combinazioni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gruppi_id1` int(11) NOT NULL,
  `gruppi_id2` int(11) NOT NULL,
  `gruppi_id3` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`gruppi_id1`,`gruppi_id2`,`gruppi_id3`),
  KEY `fk_combinazioni_gruppi1_idx` (`gruppi_id1`),
  KEY `fk_combinazioni_gruppi2_idx` (`gruppi_id2`),
  KEY `fk_combinazioni_gruppi3_idx` (`gruppi_id3`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `combinazioni`
--

/*!40000 ALTER TABLE `combinazioni` DISABLE KEYS */;
INSERT INTO `combinazioni` VALUES (1,1,5,0),(2,2,6,0),(3,3,4,0),(4,1,2,3);
/*!40000 ALTER TABLE `combinazioni` ENABLE KEYS */;

--
-- Table structure for table `eco`
--

DROP TABLE IF EXISTS `eco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eco` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eco` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eco`
--

/*!40000 ALTER TABLE `eco` DISABLE KEYS */;
INSERT INTO `eco` VALUES (1,'eco di un verso precedente o anticipazione'),(2,'NON eco di un verso precedente o anticipazione');
/*!40000 ALTER TABLE `eco` ENABLE KEYS */;

--
-- Table structure for table `gruppi`
--

DROP TABLE IF EXISTS `gruppi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gruppi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `testimoni_id1` int(11) NOT NULL,
  `testimoni_id2` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`testimoni_id1`,`testimoni_id2`),
  KEY `fk_gruppi_testimoni2_idx` (`testimoni_id2`),
  KEY `fk_gruppi_testimoni1` (`testimoni_id1`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gruppi`
--

/*!40000 ALTER TABLE `gruppi` DISABLE KEYS */;
INSERT INTO `gruppi` VALUES (1,1,0),(2,2,0),(3,3,0),(4,1,2),(5,2,3),(6,1,3);
/*!40000 ALTER TABLE `gruppi` ENABLE KEYS */;

--
-- Table structure for table `lezioni`
--

DROP TABLE IF EXISTS `lezioni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lezioni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lezione` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versi_id` int(11) NOT NULL,
  `testimoni_id` int(11) NOT NULL,
  `presenteTradizione_id` int(1) NOT NULL,
  `eco_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`versi_id`,`testimoni_id`),
  KEY `fk_lezioni_versi_idx` (`versi_id`),
  KEY `fk_lezioni_testimoni1_idx` (`testimoni_id`)
) ENGINE=MyISAM AUTO_INCREMENT=937 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lezioni`
--

/*!40000 ALTER TABLE `lezioni` DISABLE KEYS */;
INSERT INTO `lezioni` VALUES (1,'vestite',1,1,1,2),(2,'vestite',1,2,1,2),(3,'coperte *al. vestite',1,3,2,2),(4,'<strong>vestite</strong> già de’ raggi del pianeta',1,4,0,2),(5,'del',2,1,1,2),(6,'dal',2,2,1,2),(7,'dal',2,3,1,2),(8,'Temp’era <strong>dal</strong> principio del mattino,',2,4,0,2),(9,'testa alta',4,1,1,2),(10,'testa alta',4,2,1,2),(11,'testa',4,3,2,2),(12,'con la <strong>test\'alta</strong> e con rabbiosa fame,',4,4,0,2),(13,'con la sua',5,1,1,1),(14,'nella sua',5,2,1,2),(15,'nella sua',5,3,1,2),(16,'sembiava carca <strong> ne la sua</strong> magrezza',5,4,0,2),(17,'magreçça',6,1,1,2),(18,'magreçça',6,2,1,2),(19,'grameça',6,3,2,1),(20,'sembiava carca ne la sua <strong>magrezza</strong>',6,4,0,2),(21,'graveçça',7,1,1,2),(22,'graveçça',7,2,1,2),(23,'grameça',7,3,2,1),(24,'questa mi porse tanto di <strong>gravezza</strong>',7,4,0,2),(475,'pianeto',94,3,1,2),(474,'pianeto',94,2,1,2),(473,'pianeta',94,1,1,2),(616,'Da questa <strong>instanza</strong> può deliberarti',129,4,0,2),(617,'distinte',130,1,2,2),(615,'instança',129,3,1,2),(614,'instança',129,2,1,2),(612,'lumi, li quali e <strong>nel quale</strong> e nel quanto',128,4,0,2),(613,'stanzia',129,1,1,2),(618,'distrinte',130,2,2,2),(619,'distinte',130,3,2,2),(620,'da lui <strong>distratte</strong> e da lui contenute.',130,4,0,2),(607,'diamante',127,3,1,2),(476,'Lo bel <strong>pianeto</strong> che d’amar conforta',94,4,0,2),(623,'turbo',131,3,1,2),(622,'turbo',131,2,1,2),(621,'torbo',131,1,2,2),(49,'dei',8,1,1,2),(50,'dei',8,2,1,2),(51,'iddij',8,3,2,2),(52,'nel tempo de li <strong>dei</strong>dèi falsi e bugiardi',8,4,0,2),(53,'ritorni',9,1,1,2),(54,'ritorni',9,2,1,2),(55,'ti rechi',9,3,2,2),(56,'Ma tu perché <strong>ritorni</strong>  a tanta noia?',9,4,0,2),(57,'il dilectoso',10,1,1,2),(58,'il dilectoso',10,2,1,2),(59,'al dilectoso',10,3,1,2),(60,'perché non sali <strong>il dilettoso</strong>  monte',10,4,0,2),(61,'saggio',11,1,1,2),(62,'saggio',11,2,1,2),(63,'et saggio',11,3,1,2),(64,'aiutami da lei, famoso <strong>saggio</strong> ,',11,4,0,2),(65,'che la fara',12,1,1,2),(66,'che la fara',12,2,1,2),(67,'chel fara',12,3,2,2),(68,'verrà, che <strong>la</strong> farà morir con doglia.',12,4,0,2),(69,'musa',13,1,1,2),(70,'muse',13,2,1,2),(71,'muse',13,3,1,2),(72,'O <strong>muse</strong>, o alto ingegno, or m’aiutate;',13,4,0,2),(73,'maitate',14,1,2,2),(74,'maiutate',14,2,1,2),(75,'maiutate',14,3,1,2),(76,'O muse, o alto ingegno, or <strong>m’aiutate</strong>;',14,4,0,2),(77,'alma',16,1,1,2),(78,'alta',16,2,2,1),(79,'alma',16,3,1,2),(80,'ch’e’ fu de l’<strong>alma</strong> Roma e di suo impero',16,4,0,2),(81,'me',17,1,1,2),(82,'ne',17,2,1,2),(83,'ne',17,3,1,2),(84,'<strong>me</strong> degno a ciò né io né altri ’l crede.',17,4,0,2),(85,'nuovi',18,1,1,2),(86,'nuovo',18,2,2,2),(87,'nuovo',18,3,2,2),(88,'e per <strong>novi</strong> pensier cangia proposta,',18,4,0,2),(89,'da quel ciel',21,1,1,2),(90,'dal ciel',21,2,2,2),(91,'dal ciel',21,3,2,2),(92,'<strong>di quel ciel</strong> c’ ha minor li cerchi sui,',21,4,0,2),(93,'sancor *al\' se gia',22,1,2,2),(94,'se gia',22,2,1,2),(95,'se gia',22,3,1,2),(96,'che l’ubidir, <strong>se già</strong> fosse, m’è tardi;',22,4,0,2),(97,'che apririmi *al\' piu non te huopo aprirmi',23,1,1,2),(98,'aprirmi',23,2,1,2),(99,'aprirmi',23,3,1,2),(100,'più non t’è uo’ <strong>ch’aprirmi</strong> il tuo talento.',23,4,0,2),(101,'ampio',24,1,1,2),(102,'alto',24,2,2,2),(103,'alto * al\' ampio',24,3,2,2),(104,'de l’<strong>ampio</strong> loco ove tornar tu ardi\".',24,4,0,2),(105,'poi che tu vuo',25,1,1,2),(106,'da poi che vuoi',25,2,1,2),(107,'da poi che vuoi',25,3,1,2),(108,'\"<strong>Da che tu vuo’</strong> saver cotanto a dentro,',25,4,0,2),(109,'poderose',26,1,2,2),(110,'paurose',26,2,1,2),(111,'paurose',26,3,1,2),(112,'de l\'altre no, ché non son <strong>paurose</strong>.',26,4,0,2),(113,'infamia',27,1,1,2),(114,'fama',27,2,1,2),(115,'fama',27,3,1,2),(116,'che visser sanza <strong>’nfamia</strong> e sanza lodo.',27,4,0,2),(117,'cacciarli *al\' cacciangli',28,1,1,2),(118,'caccianli',28,2,1,2),(119,'caccianli',28,3,1,2),(120,'<strong>Caccianli</strong> i ciel per non esser men belli',28,4,0,2),(121,'sono *al\' tuono',29,1,2,2),(122,'tono',29,2,2,2),(123,'tono',29,3,2,2),(124,'un greve <strong>truono</strong>, sì ch’io mi riscossi',29,4,0,2),(125,'obscura profonda',30,1,1,2),(126,'obscura et profonda',30,2,1,2),(127,'obscura et profonda',30,3,1,2),(128,'<strong>Oscura e profonda</strong> era e nebulosa',30,4,0,2),(129,'a miei dubbiari',31,1,2,2),(130,'al mio dubbiare',31,2,1,2),(131,'al mio dubbiare',31,3,1,2),(132,'che suoli <strong>al mio dubbiare</strong> esser conforto?\".',31,4,0,2),(133,'cinghio',32,1,1,2),(134,'cerchio',32,2,1,2),(135,'cerchio',32,3,1,2),(136,'nel primo <strong>cerchio</strong> che l’abisso cigne',32,4,0,2),(137,'et cio',33,1,1,2),(138,'cio',33,2,1,2),(139,'cio',33,3,1,2),(140,'<strong>ciò</strong> avvenia di duol sanza martìri,',33,4,0,2),(141,'molte et grandi',34,1,1,2),(142,'molte et grandi',34,2,1,2),(143,'molto grandi',34,3,1,2),(144,'ch’avean le turbe, ch’eran <strong>molte e grandi</strong>,',34,4,0,2),(145,'avanti',35,1,1,2),(146,'avanti',35,2,1,2),(147,'innançi',35,3,1,2),(148,'Or vo’ che sappi, <strong>innanzi</strong> che più andi,',35,4,0,2),(149,'et sei furon',36,1,1,2),(150,'et se pur fur',36,2,2,2),(151,'et se pur fur',36,3,2,2),(152,'<strong>e s’e’ furon</strong> dinanzi al cristianesmo,',36,4,0,2),(153,'non',37,1,1,2),(154,'et non',37,2,1,2),(155,'et non',37,3,1,2),(156,'Per tai difetti, <strong>non</strong> per altro rio,',37,4,0,2),(157,'e lucano',38,1,1,2),(158,'lucano',38,2,1,2),(159,'lucano',38,3,1,2),(160,'Ovidio è ’l terzo, e l’ultimo <strong>Lucano</strong>.',38,4,0,2),(161,'julia martia',39,1,1,2),(162,'martia julia',39,2,1,2),(163,'martia julia',39,3,1,2),(164,'Lucrezia, <strong>Iulia, Marzïa</strong> e Corniglia;',39,4,0,2),(165,'tutti lo miran',40,1,1,2),(166,'tututti il miran',40,2,2,2),(167,'tututti il miran',40,3,2,2),(168,'<strong>Tutti lo miran</strong>, tutti onor li fanno:',40,4,0,2),(169,'tullio et lyno',41,1,1,2),(170,'tulio lino',41,2,2,2),(171,'tulio lino',41,3,2,2),(172,'<strong>Tulïo e Lino</strong> e Seneca morale;',41,4,0,2),(173,'il compianto',42,1,1,2),(174,'il compianto',42,2,1,2),(175,'col pianto',42,3,1,2),(176,'quivi le strida, <strong>il compianto</strong>, il lamento;',42,4,0,2),(177,'enno',43,1,1,2),(178,'enno',43,2,1,2),(179,'eran',43,3,1,2),(180,'<strong>enno</strong> dannati i peccator carnali,',43,4,0,2),(181,'condocta',44,1,1,2),(182,'condotta',44,2,1,2),(183,'corrotta',44,3,1,1),(184,'per tòrre il biasmo in che era <strong>condotta</strong>.',44,4,0,2),(185,'nomommi et dimostrommi',45,1,1,2),(186,'mostrommi et nominolle',45,2,1,2),(187,'mostrommi et nominolle',45,3,1,2),(188,'ombre <strong>mostrommi e nominommi</strong> a dito,',45,4,0,2),(189,'le donne antiche',46,1,1,2),(190,'lantiche donne',46,2,1,2),(191,'lantiche donne',46,3,1,2),(192,'nomar <strong>le donne antiche</strong> e ’ cavalieri,',46,4,0,2),(193,'chi a vita',47,1,1,2),(194,'chin vita',47,2,2,2),(195,'chin vita',47,3,2,2),(196,'Caina attende <strong>chi a vita</strong> ci spense\".',47,4,0,2),(197,'ci',48,1,1,2),(198,'ne',48,2,2,2),(199,'ne',48,3,2,2),(200,'Queste parole da lor <strong>ci</strong> fuor porte.',48,4,0,2),(201,'da chio',49,1,1,2),(202,'poi chio',49,2,1,2),(203,'poi chio',49,3,1,2),(204,'<strong>Quand’io</strong> intesi quell’anime offense,',49,4,0,2),(205,'queste',50,1,1,2),(206,'quelle',50,2,2,2),(207,'quelle',50,3,2,2),(208,'Quand’io intesi <strong>quell’</srong>anime offense,',50,4,0,2),(209,'pensier',51,1,1,2),(210,'pensier',51,2,1,2),(211,'sospiri',51,3,2,1),(212,'quanti dolci <strong>pensier</strong>, quanto disio',51,4,0,2),(213,'dal voler',52,1,1,2),(214,'dal voler',52,2,1,2),(215,'dal disio',52,3,1,1),(216,'vegnon per l’aere, dal <strong>voler</strong> portate;',52,4,0,2),(217,'male',53,1,2,2),(218,'amor',53,2,1,2),(219,'amor',53,3,1,2),(220,'del nostro <strong>amor</strong> tu hai cotanto affetto,',53,4,0,2),(221,'basciata',54,1,2,2),(222,'basciato',54,2,1,2),(223,'basciato',54,3,1,2),(224,'esser <strong>basciato</strong> da cotanto amante,',54,4,0,2),(225,'fia',55,1,1,2),(226,'fu',55,2,1,2),(227,'fu',55,3,1,2),(228,'questi, che mai da me non <strong>fia</strong> diviso,',55,4,0,2),(229,'teneva hor gli occhi',56,1,1,2),(230,'teneva hor gli occhi',56,2,1,2),(231,'tenendo gli occhi',56,3,2,2),(232,'dov’io <strong>tenea or li occhi</strong> sì a posta,',56,4,0,2),(233,'et di sardigna et di maremma',57,1,1,2),(234,'et di maremma et di sardigna',57,2,1,2),(235,'et di maremma et di sardigna',57,3,1,2),(236,'<strong>e di Maremma e di Sardigna</strong> i mali',57,4,0,2),(237,'dellunghia',58,1,1,2),(238,'dellunghie',58,2,1,2),(239,'dellunghie',58,3,1,2),(240,'<strong>de l’unghie</strong> sopra sé per la gran rabbia',58,4,0,2),(241,'larghe',59,1,1,2),(242,'larghe',59,2,1,2),(243,'largo',59,3,2,2),(244,'o d’altro pesce che più <strong>larghe</strong> l’abbia.',59,4,0,2),(245,'a me',60,1,1,2),(246,'a me',60,2,1,2),(247,'ad noi',60,3,2,2),(248,'e tremando ciascuno <strong>a me</strong> si volse',60,4,0,2),(249,'si',61,1,1,2),(250,'ti',61,2,1,2),(251,'ti',61,3,1,2),(252,'a dir chi è, pria che di qui <strong>si</strong> spicchi\".',61,4,0,2),(253,'bagnata',62,1,1,2),(254,'bagnate',62,2,1,2),(255,'bagnate',62,3,1,2),(256,'che fumman come man <strong>bagnate</strong> ’l verno,',62,4,0,2),(257,'a troya fosti',63,1,1,2),(258,'fosti ad troya',63,2,1,2),(259,'fosti ad troya',63,3,1,2),(260,'là ’ve del ver <strong>fosti a Troia</strong> richesto\".',63,4,0,2),(261,'molte',64,1,1,2),(262,'troppe',64,2,1,2),(263,'troppe',64,3,1,2),(264,'non vorresti a ’nvitar <strong>molte</strong> parole\".',64,4,0,2),(265,'che teco',65,1,2,2),(266,'che teco',65,2,2,2),(267,'con teco',65,3,2,2),(268,'che per poco <strong>che teco</strong> non mi risso!\".',65,4,0,2),(269,'come su',66,1,1,2),(270,'come in su',66,2,1,2),(271,'come in su',66,3,1,2),(272,'però che, <strong>come su</strong> la cerchia tonda',66,4,0,2),(273,'affibbia',67,1,1,2),(274,'saffibbia',67,2,1,2),(275,'saffibbia',67,3,1,2),(276,'dal loco in giù dov’omo<strong>affibbia</strong> ’l manto.',67,4,0,2),(277,'non vera',68,1,1,2),(278,'non era',68,2,1,2),(279,'non era',68,3,1,2),(280,'e non <strong>v’era</strong> mestier più che la dotta,',68,4,0,2),(281,'hereda',69,1,1,2),(282,'reda',69,2,1,2),(283,'reda',69,3,1,2),(284,'che fece Scipïon di gloria <strong>reda</strong>,',69,4,0,2),(285,'converrebbe',70,1,1,2),(286,'converrieno',70,2,1,2),(287,'converrieno',70,3,1,2),(288,'come si <strong>converrebbe</strong> al tristo buco',70,4,0,2),(289,'mamma et',71,1,1,2),(290,'mamma et',71,2,1,2),(291,'mamma o',71,3,1,2),(292,'né da lingua che chiami <strong>mamma o</strong> babbo.',71,4,0,2),(293,'scuro',72,1,1,2),(294,'obscuro',72,2,1,2),(295,'obscuro',72,3,1,2),(296,'Come noi fummo giù nel pozzo <strong>scuro</strong>',72,4,0,2),(297,'a me li visi',73,1,1,2),(298,'li visi ad me',73,2,1,2),(299,'li visi ad me',73,3,1,2),(300,'e poi ch’ebber <strong>li visi a me</strong> eretti,',73,4,0,2),(301,'percotendo rispose',74,1,1,2),(302,'rispose percotendo',74,2,1,2),(303,'rispose percotendo',74,3,1,2),(304,'<strong>percotendo\", rispuose</strong>, \"altrui le gote,',74,4,0,2),(305,'fiate',75,1,1,2),(306,'fiate',75,2,1,2),(307,'volte',75,3,1,2),(308,'se mille <strong>fiate</strong> in sul capo mi tomi\".',75,4,0,2),(309,'gliene avea',76,1,1,2),(310,'ne gli avea',76,2,1,2),(311,'ne gli avea',76,3,1,2),(312,'e tratti <strong>glien’avea</strong> più d’una ciocca,',76,4,0,2),(313,'con le',77,1,1,2),(314,'delle',77,2,2,2),(315,'delle',77,3,2,2),(316,'non ti basta sonar <strong>con le</strong> mascelle,',77,4,0,2),(317,'rispose',78,1,1,2),(318,'rispose',78,2,1,2),(319,'dissello',78,3,2,2),(320,'\"Va via\", <strong>rispuose</strong>, \"e ciò che tu vuoi conta;',78,4,0,2),(321,'cosi la lingua',79,1,1,2),(322,'la lingua cosi',79,2,1,2),(323,'la lingua cosi',79,3,1,2),(324,'di quel ch’ebbe or <strong>così la lingua</strong> pronta.',79,4,0,2),(325,'dissio perche',80,1,2,2),(326,'perche dissio',80,2,1,2),(327,'perche dissio',80,3,1,2),(328,'dimmi ’l <strong>perché\", diss’io</strong>, \"per tal convegno,',80,4,0,2),(329,'quel',81,1,1,2),(330,'cio',81,2,1,2),(331,'cio',81,3,1,2),(332,'pensando <strong> ciò</strong> che ’l mio cor s’annunziava;',81,4,0,2),(333,'segno',82,1,1,2),(334,'segno',82,2,1,2),(335,'sogno',82,3,1,2),(336,'e per suo <strong>sogno</strong> ciascun dubitava;',82,4,0,2),(337,'per voglia',83,1,1,2),(338,'per voglia',83,2,1,2),(339,'per fame',83,3,2,2),(340,'ed ei, pensando ch’io ’l fessi <strong>per voglia</strong>',83,4,0,2),(341,'lo di',84,1,1,2),(342,'quel di',84,2,1,2),(343,'quel di',84,3,1,2),(344,'<strong>lo dì</strong> e l’altro stemmo tutti muti;',84,4,0,2),(345,'i fligliuoi porre',85,1,1,2),(346,'porre i figliuoli',85,2,1,2),(347,'porre i figliuoli',85,3,1,2),(348,'non dovei tu <strong>i figliuoi porre</strong> a tal croce.',85,4,0,2),(349,'di voi un tal',86,1,1,2),(350,'io un di voi',86,2,2,2),(351,'io un di voi',86,3,2,2),(352,'trovai <strong> di voi un tal</strong>, che per sua opra',86,4,0,2),(353,'si convenia',87,1,1,2),(354,'si conveniano',87,2,2,2),(355,'si conveniano',87,3,2,2),(356,'quanto <strong>si convenia</strong> a tanto uccello:',87,4,0,2),(357,'vellute',88,1,1,2),(358,'lanute',88,2,2,2),(359,'lanute',88,3,2,2),(360,'appigliò sé a le <strong>vellute</strong> coste;',88,4,0,2),(361,'puose me',89,1,1,2),(362,'posemi ivi',89,2,2,2),(363,'posemi ivi',89,3,2,2),(364,'e <strong>puose me</strong> in su l’orlo a sedere;',89,4,0,2),(365,'consunto',90,1,1,2),(366,'consuncto',90,2,1,2),(367,'congiunto',90,3,2,1),(368,'coverchia, e sotto ’l cui colmo <strong>consunto</strong>',90,4,0,2),(369,'or cantero',91,1,2,2),(370,'et cantero',91,2,1,2),(371,'et cantero',91,3,1,2),(372,'<strong>e canterò</strong> di quel secondo regno',91,4,0,2),(373,'da laer',92,1,1,2),(374,'dal meço',92,2,1,2),(375,'dal meço',92,3,1,2),(376,'<strong>del mezzo</strong>, puro infino al primo giro,',92,4,0,2),(377,'ricomincio',93,1,1,2),(378,'ricomincio',93,2,1,2),(379,'incomincio',93,3,1,2),(380,'a li occhi miei <strong>ricominciò</strong> diletto,',93,4,0,2),(611,'nel come',128,3,2,2),(610,'nel come',128,2,2,2),(609,'nel quale',128,1,1,2),(608,'quasi <strong>adamante</strong> che lo sol ferisse.',127,4,0,2),(385,'alto polo',95,1,1,2),(606,'diamante',127,2,1,2),(605,'adamante',127,1,1,2),(604,'cui non potea mia <strong>cura</strong> essere ascosa,',126,4,0,2),(603,'cura',126,3,1,2),(602,'ovra',126,2,1,2),(601,'opra',126,1,1,2),(600,'quando Iasón <strong>vider</strong> fatto bifolco.',125,4,0,2),(599,'vidon',125,3,1,2),(598,'vider',125,2,1,2),(597,'vider',125,1,1,2),(596,'e <strong>nove</strong> Muse mi dimostran l’Orse.',124,4,0,2),(595,'nuove',124,3,1,2),(594,'nuove',124,2,1,2),(593,'nove',124,1,1,2),(592,'Non dei più ammirar, se bene <strong>stimo</strong>,',123,4,0,2),(591,'stimo',123,3,1,2),(590,'stimo',123,2,1,2),(589,'extimo',123,1,1,2),(588,'l’atterra <strong>torto</strong> da falso piacere.',122,4,0,2),(587,'torta',122,3,1,2),(586,'torto',122,2,1,2),(585,'torto',122,1,1,2),(409,'onestade',101,1,1,2),(410,'onesta',101,2,1,2),(411,'onesta',101,3,1,2),(412,'che l’<strong>onestade</strong> ad ogn’atto dismaga,',101,4,0,2),(413,'possa',102,1,1,2),(414,'possa',102,2,1,2),(415,'po',102,3,2,2),(416,'\"sì che <strong>possa</strong> salir chi va sanz’ala?\"',102,4,0,2),(580,'con l’armonia che temperi e <strong>discerni</strong>,',120,4,0,2),(579,'discerni',120,3,1,2),(578,'discerni',120,2,1,2),(577,'iscerni',120,1,1,2),(576,'com’ <strong>ferro che bogliente</strong> esce del foco;',119,4,0,2),(575,'ferro bogliente',119,3,1,2),(574,'ferro che bogliente',119,2,1,2),(573,'ferro che bogliente',119,1,1,2),(429,'su',106,1,1,2),(430,'in su',106,2,1,2),(431,'in su',106,3,1,2),(432,'Poi che noi fummo <strong>in su</strong> l’orlo suppremo',106,4,0,2),(433,'di retro',107,1,1,2),(434,'una retro',107,2,2,2),(435,'una retro',107,3,2,2),(436,'quando <strong>di retro</strong> a me, drizzando ’l dito,',107,4,0,2),(437,'una grido',108,1,1,2),(438,'forte grido',108,2,2,2),(439,'forte grido',108,3,2,2),(440,'<strong>una gridò</strong>: \"Ve’ che non par che luca',108,4,0,2),(441,'ridir',109,1,1,2),(442,'piu dir',109,2,2,2),(443,'piu dir',109,3,2,2),(444,'Che potea io <strong>ridir</strong>, se non \"Io vegno\"?',109,4,0,2),(563,'venir vedrami al tuo',116,3,1,1),(562,'venir vedrami al tuo',116,2,1,1),(561,'vedrami al pie del tuo',116,1,1,2),(560,'né sa né può <strong>chi</strong> di là sù discende;',115,4,0,2),(559,'chi',115,3,1,2),(558,'chi',115,2,1,2),(557,'qual',115,1,1,2),(457,'rubesto',113,1,1,2),(458,'rubesto',113,2,1,2),(459,'robusto',113,3,2,2),(460,'trovò l’Archian <strong>rubesto</strong>; e quel sospinse',113,4,0,2),(478,'altro polo',95,2,1,2),(479,'altro polo',95,3,1,2),(480,'a l\'<strong>altro polo</strong>, e vidi quattro stelle',95,4,0,2),(481,'che contro',96,1,1,2),(482,'che contro',96,2,1,2),(483,'chencontro',96,3,1,2),(484,'\"Chi siete voi <strong>che contro</strong> al cieco fiume',96,4,0,2),(485,'fu mandato',97,1,1,2),(486,'fu mandato',97,2,1,2),(487,'fui mandato',97,3,1,2),(488,'Sì com’io dissi, <strong>fui mandato</strong> ad esso',97,4,0,2),(489,'le vermiglie',98,1,1,2),(490,'vermiglie',98,2,2,2),(491,'vermiglie',98,3,2,2),(492,'sì che le bianche e <strong>le vermiglie</strong> guance,',98,4,0,2),(493,'apparver',99,1,1,2),(494,'aperser',99,2,1,2),(495,'aperser',99,3,1,2),(496,'mentre che i primi bianchi <strong>apparver</strong> ali;',99,4,0,2),(497,'eran',100,1,1,2),(498,'era',100,2,2,2),(499,'era',100,3,2,2),(500,'ch’<strong>eran</strong> con lui parevan sì contenti,',100,4,0,2),(584,'e cominciò: \"<strong>Tu stesso</strong> ti fai grosso',121,4,0,2),(583,'tu stessi',121,3,1,2),(582,'tu stessi',121,2,1,2),(581,'tu stesso',121,1,1,2),(509,'dissi al',103,1,1,2),(510,'dissi io',103,2,1,2),(511,'dissi io',103,3,1,2),(512,'\"Leva\", <strong>diss’io</strong>, \"maestro, li occhi tuoi:',103,4,0,2),(513,'rivolve',104,1,1,2),(514,'rivolge',104,2,1,2),(515,'rivolge',104,3,1,2),(516,'che prende ciò che si <strong>rivolge</strong> a lei.',104,4,0,2),(517,'et piede et man',105,1,1,2),(518,'et man et pie',105,2,1,2),(519,'et man et pie',105,3,1,2),(520,'<strong>e piedi e man</strong> volea il suol di sotto.',105,4,0,2),(572,'ne l’<strong>imagine mia</strong>, il mio si fece,',118,4,0,2),(571,'ymagine',118,3,2,2),(570,'ymagine mia',118,2,1,2),(569,'ymagine mia',118,1,1,2),(568,'<strong>venire, e coronarmi de le foglie</strong>',117,4,0,2),(567,'et coronarmi allor di quelle foglie',117,3,1,2),(566,'et coronarmi allor di quelle foglie',117,2,1,2),(565,'venire et coronarmi delle foglie',117,1,1,2),(564,'<strong>vedra’ mi al piè del tuo</strong> diletto legno',116,4,0,2),(537,'passi',110,1,1,2),(538,'passi',110,2,1,2),(539,'piedi',110,3,1,2),(540,'che, dietro a’ <strong>piedi</strong> di sì fatta guida,',110,4,0,2),(541,'padule',111,1,1,2),(542,'padule',111,2,1,2),(543,'palude',111,3,1,2),(544,'Corsi al <strong>palude</strong>, e le cannucce e ’l braco',111,4,0,2),(545,'di montefeltro',112,1,1,2),(546,'da montefeltro',112,2,1,2),(547,'da montefeltro',112,3,1,2),(548,'Io fui <strong>di Montefeltro</strong>, io son Bonconte;',112,4,0,2),(556,'<strong>in una parte</strong> più e meno altrove.',114,4,0,2),(555,'in una parte',114,3,1,2),(553,'in alcun luogo',114,1,2,2),(554,'in una parte',114,2,1,2),(624,'conforme a sua bontà, lo <strong>turbo</strong> e ’l chiaro\".',131,4,0,2),(625,'il tuo',132,1,1,2),(626,'al tuo',132,2,2,2),(627,'al tuo',132,3,2,2),(628,'mi disse, \"appresso <strong>il tuo</strong> püeril coto,',132,4,0,2),(629,'vostri',133,1,1,2),(630,'vostri',133,2,1,2),(631,'vostro',133,3,2,2),(632,'<strong>vostri</strong> risplende non so che divino',133,4,0,2),(633,'come al re',134,1,1,2),(634,'si come al re',134,2,1,2),(635,'si come al re',134,3,1,2),(636,'<strong>com’a lo re</strong> che ’n suo voler ne ’nvoglia.',134,4,0,2),(637,'si sa',135,1,1,2),(638,'sel sa',135,2,1,2),(639,'sel sa',135,3,1,2),(640,'Iddio <strong>si sa</strong> qual poi mia vita fusi.',135,4,0,2),(641,'ecterno spiro',136,1,1,2),(642,'dolce spiro',136,2,2,2),(643,'dolce spiro',136,3,2,2),(644,'per sentir più e men <strong>l’etterno spiro.</strong>',136,4,0,2),(645,'li',137,1,1,2),(646,'qui',137,2,1,2),(647,'qui',137,3,1,2),(648,'<strong>Qui</strong> si mostraro, non perché sortita',137,4,0,2),(649,'gabriel et michel',138,1,1,2),(650,'michele et gabriel',138,2,2,2),(651,'michele et gabriel',138,3,2,2),(652,'<strong>Gabrïel e Michel</strong> vi rappresenta,',138,4,0,2),(653,'come',139,1,2,2),(654,'cosi',139,2,1,2),(655,'cosi',139,3,1,2),(656,'<strong>così</strong> l’avria ripinte per la strada',139,4,0,2),(657,'facto noia',140,1,1,2),(658,'facta noia',140,2,2,2),(659,'facta noia',140,3,2,2),(660,'che t’avria <strong>fatto noia</strong> ancor più volte.',140,4,0,2),(661,'in tanto quanto',141,1,1,2),(662,'in tanto in quanto',141,2,1,2),(663,'in tanto in quanto',141,3,1,2),(664,'ma consentevi <strong>in tanto in quanto</strong> teme,',141,4,0,2),(665,'expreme',142,1,1,2),(666,'spreme',142,2,1,2),(667,'spreme',142,3,1,2),(668,'Però, quando Piccarda quello <strong>spreme</strong>,',142,4,0,2),(669,'come risplende',143,1,1,2),(670,'come gia risplende',143,2,1,2),(671,'come gia risplende',143,3,1,2),(672,'Io veggio ben sì come <strong>già resplende</strong>',143,4,0,2),(673,'spreça',144,1,1,2),(674,'speça',144,2,1,2),(675,'speça',144,3,1,2),(676,'e sì com’uom che suo parlar non<strong>spezza</strong>,',144,4,0,2),(677,'tutte et sole',145,1,1,2),(678,'et tutte et sole',145,2,1,2),(679,'et tutte et sole',145,3,1,2),(680,'<strong>e tutte e sole</strong>, fuoro e son dotate.',145,4,0,2),(681,'necessitato',146,1,1,2),(682,'necessita',146,2,1,2),(683,'necessita',146,3,1,2),(684,'però <strong>necessitato</strong> fu a li Ebrei',146,4,0,2),(685,'cui piu',147,1,1,2),(686,'che piu',147,2,2,2),(687,'che piu',147,3,2,2),(688,'<strong>cui più</strong> si convenia dicer ’Mal feci’,',147,4,0,2),(689,'il nuovo el vecchio',148,1,1,2),(690,'il vecchio el nuovo',148,2,1,2),(691,'il vecchio el nuovo',148,3,1,2),(692,'Avete <strong>il novo e ’l vecchio</strong> Testamento,',148,4,0,2),(693,'parte',149,1,1,2),(694,'per te',149,2,1,2),(695,'per te',149,3,1,2),(696,'e <strong> per te</strong> vederai come da questi',149,4,0,2),(697,'come',151,1,2,2),(698,'et come',151,2,1,2),(699,'e ch\'io mi volga, <strong>e come</strong> che io guati',151,4,0,2),(700,'et come',151,3,1,2),(701,'tenebroso',152,2,1,2),(702,'tenebroso',152,3,1,2),(703,'tenebrosa',152,1,1,2),(704,'per l\'aere <strong>tenebroso</strong> si riversa',152,4,0,2),(705,'questa',153,3,2,2),(706,'questo',153,1,1,2),(707,'pute la terra che <strong>questo</strong> riceve',153,4,0,2),(708,'questo',153,2,1,2),(709,'de lo',154,4,0,2),(710,'che solo',154,1,1,2),(711,'et solo',154,2,1,2),(712,'et solo',154,3,1,2),(713,'di quel',155,2,2,2),(714,'di quel',155,3,2,2),(715,'<strong>de lo</strong>  demonio Cerbero, che \'ntrona',155,4,0,2),(716,'dello',155,1,1,2),(717,'E io <strong>a lui</strong> : «l\'angoscia che hai',156,4,0,2),(718,'allei',156,1,1,2),(719,'allui',156,2,1,2),(720,'allui',156,3,1,2),(721,'che, s\'altra è <strong>maggio</strong> , nulla è si spiacente»',157,4,0,2),(722,'maggio',157,3,1,2),(723,'maggia',157,1,1,2),(724,'maggio',157,2,1,2),(725,'e si',158,1,1,2),(726,'e si',158,2,1,2),(727,'e piu',158,3,1,2),(728,'che, s\'altra è maggio, nulla <strong>è si</strong>  spiacente»',158,4,0,2),(729,'con la fora',159,3,1,2),(730,'<strong>con la forza</strong> di tal che testé piaggia',159,4,0,2),(731,'per la força',159,1,2,2),(732,'con la força',159,2,1,2),(733,'alto',160,3,1,2),(734,'alte',160,1,1,2),(735,'alte',160,2,1,2),(736,'<strong>Alte</strong> terrà lungo tempo le fronti',160,4,0,2),(737,'o',161,3,1,2),(738,'o',161,2,1,2),(739,'Giusti son due, <strong>e</strong> non vi sono intesi',161,4,0,2),(740,'et',161,1,1,2),(741,'gli grava',162,1,1,2),(742,'gli aggrava',162,2,1,2),(743,'gli aggrava',162,3,1,2),(744,'diverse colpe giù <strong>li grava</strong> al fondo',162,4,0,2),(745,'giudicio',163,3,2,1),(746,'Ahi  <strong>giustizia</strong> di Dio! Tante chi stipa',163,4,0,2),(747,'giustitia',163,1,1,2),(748,'giustitia',163,2,1,2),(749,'uso',164,3,1,2),(750,'in cui  <strong>usa</strong> avarizia il suo soperchio',164,4,0,2),(751,'uso',164,2,1,2),(752,'usa',164,1,1,2),(753,'figliuol veder',165,1,1,2),(754,'veder figliuolo',165,2,1,2),(755,'veder figliuolo',165,3,1,2),(756,'Or puoi,  <strong>figliuol, veder</strong> la corta buffa',165,4,0,2),(757,'seguitando il',166,2,2,2),(758,'seguitandol',166,3,2,2),(759,'seguendo lo',166,1,1,2),(760,'<strong>seguendo lo</strong> giudicio di costei',166,4,0,2),(761,'volge',167,1,1,2),(762,'volve',167,3,1,2),(763,'<strong>volve</strong> sua spera e beata si gode',167,4,0,2),(764,'volve',167,2,1,2),(765,'Nella palude va',168,2,1,2),(766,'Nella paluda va',168,3,1,2),(767,'Una palude va (ad marg. c. fa)',168,1,1,2),(768,'<strong>In la palude va</strong> c\'ha nome Stige',168,4,0,2),(769,'sommo',169,3,1,2),(770,'sommo',169,2,1,2),(771,'e fanno pullular quest\'acqua al  <strong>summo</strong>',169,4,0,2),(772,'summo',169,1,1,2),(773,'puoi scorger',170,1,1,2),(774,'scorger puoi',170,2,1,2),(775,'scorger puoi',170,3,1,2),(776,'gia  <strong>scorgere puoi</strong> quello che s\'aspetta',170,4,0,2),(777,'cosi',171,3,2,2),(778,'Corda non pinse mai  <strong>da se</strong> saetta',171,4,0,2),(779,'da se',171,1,1,2),(780,'da se',171,2,1,2),(781,'fecesi tal',172,3,2,2),(782,'<strong>fecesi</strong> Flegïas ne l\'ira accolta',172,4,0,2),(783,'fecesi tal',172,2,2,2),(784,'tal si fece',172,1,2,2),(785,'sarei',173,1,1,2),(786,'sarei',173,2,1,2),(787,'saria',173,3,1,2),(788,'E io «Maestro, molto  <strong>sarei</strong> vago»',173,4,0,2),(789,'prima',174,2,1,2),(790,'prima',174,3,1,2),(791,'ançi',174,1,2,2),(792,'<strong>prima</strong> che noi uscissimo dal lago',174,4,0,2),(793,'uscissimo',175,1,1,2),(794,'uscissimo',175,3,1,2),(795,'prima che noi <strong>uscissimo</strong> dal lago',175,4,0,2),(796,'uscissomo',175,2,1,2),(797,'ne lodo ancora',176,2,1,2),(798,'che Dio <strong>ancora ne lodo</strong> e ne ringrazio',176,4,0,2),(799,'ancor ne lodo',176,1,1,2),(800,'ne lodo ancora',176,3,1,2),(801,'grande',177,1,1,2),(802,'grave',177,2,2,1),(803,'grave',177,3,2,1),(804,'coi gravi cittadin, col<strong> grande</strong> stuolo»',177,4,0,2),(805,'et el',178,2,1,2),(806,'et el',178,3,1,2),(807,'et quei',178,1,1,2),(808,'fossero».  <strong>Ed ei</strong> mi disse «Il foco etterno',178,4,0,2),(809,'terra (ad marg. al. ferro)',179,1,1,1),(810,'ferro',179,2,1,2),(811,'ferro',179,3,1,2),(812,'le mura mi parean che <strong>ferro</strong> fosse',179,4,0,2),(813,'dalto (ad marg. al. daltro)',180,1,1,2),(814,'daltro',180,2,1,2),(815,'daltro',180,3,1,2),(816,'<strong>d\'alto</strong> periglio che \'ncontra mi stette',180,4,0,2),(817,'che si et no (ad marg. al. chel si el no)',181,1,1,2),(818,'chel no el si',181,2,2,2),(819,'chel no el si',181,3,2,2),(820,'<strong>che si e no</strong> nel capo mi tenciona',181,4,0,2),(821,'poteio',182,1,1,2),(822,'potti',182,2,1,2),(823,'Udir non <strong>potti</strong> quello ch\'a lor porse',182,4,0,2),(824,'potti',182,3,1,2),(825,'serpentelli et',183,2,1,2),(826,'serpentelli et',183,3,1,2),(827,'serpentelli',183,1,1,2),(828,'<strong>serpentelli e ceraste</strong> avien per crine',183,4,0,2),(829,'conobber',184,3,2,2),(830,'conobbe',184,1,2,2),(831,'E quei, che ben <strong>conobbe</strong> le meschine',184,4,0,2),(832,'conobbe',184,1,1,2),(833,'trine',185,1,1,2),(834,'crine',185,2,1,2),(835,'crine',185,3,1,2),(836,'«Guarda», mi disse, «le feroci <strong>Erine</strong>.',185,4,0,2),(837,'sattenne',186,3,2,2),(838,'mi volse, e non <strong>si tenne</strong> a le mie mani',186,4,0,2),(839,'si tenne',186,1,1,2),(840,'sattenne',186,2,2,2),(841,'et sença',187,3,1,2),(842,'che fier la selva <strong>e sanz\'</strong>alcun rattento',187,4,0,2),(843,'et sença',187,2,1,2),(844,'sença',187,1,1,2),(845,'fiori (ad marg. fuori)',188,1,1,2),(846,'fuori',188,2,1,2),(847,'fuori',188,3,1,2),(848,'li rami schianta, abbatte e porta <strong>fori</strong>;',188,4,0,2),(849,'hor driça',189,2,1,2),(850,'hor driça',189,3,1,2),(851,'driçça',189,1,1,2),(852,'Li occhi mi sciolse e disse: «<strong>Or drizza</strong> il nerbo»',189,4,0,2),(853,'ove e quel fummo piu',190,1,2,2),(854,'onde quel fummo e piu',190,3,1,2),(855,'per indi ove <strong>quel fummo è più</strong> acerbo',190,4,0,2),(856,'onde quel fummo e piu',190,2,1,2),(857,'cheto',191,2,1,2),(858,'ch\'i stessi <strong>queto</strong> ed inchinassi ad esso',191,4,0,2),(859,'queto',191,1,1,2),(860,'cheto',191,3,1,2),(861,'laperse',192,1,1,2),(862,'vaperse',192,2,2,1),(863,'laperse',192,3,1,2),(864,'<strong>l\'aperse</strong>, che non v\'ebbe alcun ritegno',192,4,0,2),(865,'vebbe',193,2,1,2),(866,'vebbe',193,3,1,2),(867,'ebbe',193,1,1,2),(868,'l\'aperse, che non <strong>v\'ebbe</strong> alcun ritegno',193,4,0,2),(869,'amaro',194,1,1,2),(870,'amaro',194,2,1,2),(871,'avaro',194,3,2,1),(872,'salvo che \'l modo v\'era più <strong>amaro</strong>',194,4,0,2),(873,'monimenti',195,1,1,2),(874,'monumenti',195,2,1,2),(875,'monumenti',195,3,1,2),(876,'e i <strong>monimenti</strong> son più e men caldi»',195,4,0,2),(877,'Suo cimitero',196,1,1,2),(878,'Suoi cimiteri',196,2,1,2),(879,'Suoi cimiteri',196,3,1,2),(880,'<strong>Suo cimitero</strong> da questa parte hanno',196,4,0,2),(881,'avea',197,1,1,2),(882,'avea già',197,2,1,2),(883,'Io <strong>avea già</strong> il mio viso nel suo fitto',197,4,0,2),(884,'avea già',197,3,1,2),(885,'et luna',198,2,2,2),(886,'rispuos\'io lui «<strong>-l\'una</strong> e l\'altra fiata»',198,4,0,2),(887,'luna',198,1,1,2),(888,'et luna',198,3,2,2),(889,'fino',200,1,1,2),(890,'infino',200,2,1,2),(891,'infino',200,3,1,2),(892,'un\'ombra, lungo questa, <strong>infino al mento </strong>',200,4,0,2),(893,'fu tutto spento',201,2,1,2),(894,'tutto fu spento',201,3,1,2),(895,'e poi che \'l sospecciar <strong>fu tutto spento</strong>',201,4,0,2),(896,'fu tutto spento',201,1,1,2),(897,'grido',202,1,1,2),(898,'disse',202,2,1,2),(899,'Di sùbito drizzato <strong>gridò</strong> «Come?',202,4,0,2),(900,'disse',202,3,1,2),(901,'segli',203,2,1,2),(902,'segli',203,3,1,2),(903,'egli',203,1,1,2),(904,'«<strong>-S\'elli</strong> han quell\'arte», disse «male appresa',203,4,0,2),(905,'tali orationi',204,1,1,2),(906,'tale oration',204,2,1,2),(907,'tale oration',204,3,1,2),(908,'<strong>tal oration</strong> fa far nel nostro tempio»',204,4,0,2),(909,'accio non fu io sol disse',205,1,1,2),(910,'disse a cio non fui io sol',205,2,1,2),(911,'disse a cio non fui io sol',205,3,1,2),(912,'«<strong>A ciò non fu\' io sol</strong>», disse, «né certo»',205,4,0,2),(913,'chel tempo',206,1,1,2),(914,'che tempo',206,2,1,2),(915,'dinanzi quel <strong>che \'l tempo</strong> seco adduce',206,4,0,2),(916,'chel tempo',206,3,1,2),(917,'co vivi',207,2,1,2),(918,'co vivi',207,3,1,2),(919,'tra vivi',207,1,1,2),(920,'che \'l suo nato è <strong>co\' vivi</strong> ancor congiunto;',207,4,0,2),(921,'ne disse',208,1,1,2),(922,'disse',208,2,1,2),(923,'disse',208,3,1,2),(924,'<strong>mi disse</strong>: «Perché se\' tu sì smarrito?»',208,4,0,2),(925,'et acqua',278,1,1,2),(926,'acqua',278,2,1,2),(927,'acqua',278,3,1,2),(928,'Grandine grossa,<strong> acqua</strong> tinta e neve',278,4,0,2),(929,'si vengo',406,1,1,2),(930,'sio vegno io',406,2,1,2),(931,'sio vegno io',406,3,1,2),(932,'E io a lui: «S\'i vegno, non rimango»',406,4,0,2),(933,'sergea',407,1,1,2),(934,'sergea',407,2,1,2),(935,'surgea',407,3,1,2),(936,'ed el s\'ergea col petto e con la fronte',407,4,0,2);
/*!40000 ALTER TABLE `lezioni` ENABLE KEYS */;

--
-- Table structure for table `presenteTradizione`
--

DROP TABLE IF EXISTS `presenteTradizione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presenteTradizione` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `presente` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presenteTradizione`
--

/*!40000 ALTER TABLE `presenteTradizione` DISABLE KEYS */;
INSERT INTO `presenteTradizione` VALUES (1,'presente nella tradizione'),(2,'assente nella tradizione');
/*!40000 ALTER TABLE `presenteTradizione` ENABLE KEYS */;

--
-- Table structure for table `rima`
--

DROP TABLE IF EXISTS `rima`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rima` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rima` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rima`
--

/*!40000 ALTER TABLE `rima` DISABLE KEYS */;
INSERT INTO `rima` VALUES (1,'in rima'),(2,'non in rima');
/*!40000 ALTER TABLE `rima` ENABLE KEYS */;

--
-- Table structure for table `testimoni`
--

DROP TABLE IF EXISTS `testimoni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testimoni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sigla` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `testimone` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testimoni`
--

/*!40000 ALTER TABLE `testimoni` DISABLE KEYS */;
INSERT INTO `testimoni` VALUES (1,'A','Toledano'),(2,'B','Riccardiano'),(3,'C','Chigiano'),(4,'P','ed. Petrocchi');
/*!40000 ALTER TABLE `testimoni` ENABLE KEYS */;

--
-- Table structure for table `versi`
--

DROP TABLE IF EXISTS `versi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `versi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cantica_id` int(1) DEFAULT NULL,
  `canto_id` int(2) DEFAULT NULL,
  `canto_numero` decimal(5,2) NOT NULL,
  `verso` int(7) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cantica` (`cantica_id`),
  KEY `fk_canto` (`canto_id`),
  KEY `canto_numero` (`canto_numero`)
) ENGINE=MyISAM AUTO_INCREMENT=408 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versi`
--

/*!40000 ALTER TABLE `versi` DISABLE KEYS */;
INSERT INTO `versi` VALUES (1,1,1,1.01,17),(2,1,1,1.01,37),(3,1,1,1.01,46),(4,1,1,1.01,47),(5,1,1,1.01,50),(6,1,1,1.01,50),(7,1,1,1.01,52),(8,1,1,1.01,72),(9,1,1,1.01,76),(10,1,1,1.01,77),(11,1,1,1.01,89),(12,1,1,1.01,102),(13,1,2,1.02,7),(14,1,2,1.02,7),(15,1,2,1.02,18),(16,1,2,1.02,20),(17,1,2,1.02,33),(18,1,2,1.02,38),(19,1,2,1.02,42),(20,1,2,1.02,67),(21,1,2,1.02,78),(22,1,2,1.02,80),(23,1,2,1.02,81),(24,1,2,1.02,84),(25,1,2,1.02,85),(26,1,2,1.02,90),(27,1,3,1.03,36),(28,1,3,1.03,40),(29,1,4,1.04,2),(30,1,4,1.04,10),(31,1,4,1.04,18),(32,1,4,1.04,24),(33,1,4,1.04,28),(34,1,4,1.04,29),(35,1,4,1.04,33),(36,1,4,1.04,37),(37,1,4,1.04,40),(38,1,4,1.04,90),(39,1,4,1.04,128),(40,1,4,1.04,133),(41,1,4,1.04,141),(42,1,5,1.05,35),(43,1,5,1.05,38),(44,1,5,1.05,57),(45,1,5,1.05,68),(46,1,5,1.05,71),(47,1,5,1.05,107),(48,1,5,1.05,108),(49,1,5,1.05,109),(50,1,5,1.05,109),(51,1,5,1.05,113),(52,1,5,1.05,120),(53,1,5,1.05,125),(54,1,5,1.05,134),(55,1,5,1.05,135),(56,1,29,1.29,19),(57,1,29,1.29,48),(58,1,29,1.29,80),(59,1,29,1.29,84),(60,1,29,1.29,98),(61,1,30,1.30,36),(62,1,30,1.30,92),(63,1,30,1.30,114),(64,1,30,1.30,129),(65,1,30,1.30,132),(66,1,31,1.31,40),(67,1,31,1.31,66),(68,1,31,1.31,110),(69,1,31,1.31,116),(70,1,32,1.32,2),(71,1,32,1.32,9),(72,1,32,1.32,16),(73,1,32,1.32,45),(74,1,32,1.32,89),(75,1,32,1.32,102),(76,1,32,1.32,104),(77,1,32,1.32,107),(78,1,32,1.32,112),(79,1,32,1.32,114),(80,1,32,1.32,135),(81,1,33,1.33,41),(82,1,33,1.33,45),(83,1,33,1.33,59),(84,1,33,1.33,65),(85,1,33,1.33,87),(86,1,33,1.33,155),(87,1,34,1.34,47),(88,1,34,1.34,73),(89,1,34,1.34,86),(90,1,34,1.34,114),(91,2,1,2.01,4),(92,2,1,2.01,15),(93,2,1,2.01,16),(94,2,1,2.01,19),(95,2,1,2.01,23),(96,2,1,2.01,40),(97,2,1,2.01,61),(98,2,2,2.02,7),(99,2,2,2.02,26),(100,2,2,2.02,116),(101,2,3,2.03,11),(102,2,3,2.03,54),(103,2,3,2.03,61),(104,2,3,2.03,123),(105,2,4,2.04,33),(106,2,4,2.04,34),(107,2,5,2.05,3),(108,2,5,2.05,4),(109,2,5,2.05,19),(110,2,5,2.05,62),(111,2,5,2.05,82),(112,2,5,2.05,88),(113,2,5,2.05,125),(114,3,1,3.01,3),(115,3,1,3.01,6),(116,3,1,3.01,25),(117,3,1,3.01,26),(118,3,1,3.01,53),(119,3,1,3.01,60),(120,3,1,3.01,78),(121,3,1,3.01,88),(122,3,1,3.01,135),(123,3,1,3.01,136),(124,3,2,3.02,9),(125,3,2,3.02,18),(126,3,2,3.02,27),(127,3,2,3.02,33),(128,3,2,3.02,65),(129,3,2,3.02,94),(130,3,2,3.02,117),(131,3,2,3.02,148),(132,3,3,3.03,26),(133,3,3,3.03,59),(134,3,3,3.03,84),(135,3,3,3.03,108),(136,3,4,3.04,36),(137,3,4,3.04,37),(138,3,4,3.04,47),(139,3,4,3.04,85),(140,3,4,3.04,90),(141,3,4,3.04,110),(142,3,4,3.04,112),(143,3,5,3.05,7),(144,3,5,3.05,17),(145,3,5,3.05,24),(146,3,5,3.05,49),(147,3,5,3.05,67),(148,3,5,3.05,76),(149,3,5,3.05,112),(150,1,18,1.18,128),(151,1,6,1.06,6),(152,1,6,1.06,11),(153,1,6,1.06,12),(154,1,6,1.06,30),(155,1,6,1.06,32),(156,1,6,1.06,43),(157,1,6,1.06,48),(158,1,6,1.06,48),(159,1,6,1.06,69),(160,1,6,1.06,70),(161,1,6,1.06,71),(162,1,6,1.06,86),(163,1,7,1.07,19),(164,1,7,1.07,48),(165,1,7,1.07,61),(166,1,7,1.07,83),(167,1,7,1.07,96),(168,1,7,1.07,106),(169,1,7,1.07,119),(170,1,8,1.08,11),(171,1,8,1.08,13),(172,1,8,1.08,24),(173,1,8,1.08,52),(174,1,8,1.08,54),(175,1,8,1.08,54),(176,1,8,1.08,60),(177,1,8,1.08,69),(178,1,8,1.08,73),(179,1,8,1.08,78),(180,1,8,1.08,99),(181,1,8,1.08,111),(182,1,8,1.08,112),(183,1,9,1.09,41),(184,1,9,1.09,43),(185,1,9,1.09,45),(186,1,9,1.09,59),(187,1,9,1.09,69),(188,1,9,1.09,70),(189,1,9,1.09,73),(190,1,9,1.09,75),(191,1,9,1.09,87),(192,1,9,1.09,90),(193,1,9,1.09,90),(194,1,9,1.09,117),(195,1,9,1.09,131),(196,1,10,1.10,13),(197,1,10,1.10,34),(198,1,10,1.10,50),(199,1,10,1.10,76),(200,1,10,1.10,53),(201,1,10,1.10,57),(202,1,10,1.10,67),(203,1,10,1.10,77),(204,1,10,1.10,87),(205,1,10,1.10,89),(206,1,10,1.10,98),(207,1,10,1.10,111),(208,1,10,1.10,125),(209,1,11,1.11,36),(210,1,11,1.11,37),(211,1,11,1.11,53),(212,1,11,1.11,67),(213,1,11,1.11,96),(214,1,12,1.12,10),(215,1,12,1.12,12),(216,1,12,1.12,15),(217,1,12,1.12,43),(218,1,12,1.12,56),(219,1,12,1.12,57),(220,1,12,1.12,58),(221,1,12,1.12,81),(222,1,12,1.12,94),(223,1,12,1.12,99),(224,1,12,1.12,121),(225,1,12,1.12,126),(226,1,12,1.12,129),(227,1,12,1.12,131),(228,1,13,1.13,13),(229,1,13,1.13,15),(230,1,13,1.13,16),(231,1,13,1.13,47),(232,1,13,1.13,80),(233,1,13,1.13,90),(234,1,13,1.13,116),(235,1,13,1.13,123),(236,1,13,1.13,128),(237,1,13,1.13,130),(238,1,14,1.14,36),(239,1,14,1.14,70),(240,1,14,1.14,59),(241,1,14,1.14,82),(242,1,14,1.14,105),(243,1,14,1.14,139),(244,1,15,1.15,5),(245,1,15,1.15,17),(246,1,15,1.15,18),(247,1,15,1.15,36),(248,1,15,1.15,37),(249,1,15,1.15,83),(250,1,15,1.15,87),(251,1,15,1.15,94),(252,1,15,1.15,104),(253,1,15,1.15,119),(254,1,15,1.15,124),(255,1,16,1.16,21),(256,1,16,1.16,28),(257,1,16,1.16,61),(258,1,16,1.16,105),(259,1,16,1.16,109),(260,1,16,1.16,120),(261,1,16,1.16,123),(262,1,17,1.17,6),(263,1,17,1.17,19),(264,1,17,1.17,27),(265,1,17,1.17,43),(266,1,17,1.17,47),(267,1,17,1.17,55),(268,1,17,1.17,75),(269,1,17,1.17,79),(270,1,17,1.17,80),(271,1,17,1.17,127),(272,1,18,1.18,26),(273,1,18,1.18,55),(274,1,18,1.18,6),(275,1,18,1.18,79),(276,1,18,1.18,80),(277,1,18,1.18,93),(278,1,6,1.06,10),(279,1,18,1.18,129),(280,1,18,1.18,130),(281,1,19,1.19,19),(282,1,19,1.19,25),(283,1,19,1.19,29),(284,1,19,1.19,30),(285,1,19,1.19,30),(286,1,19,1.19,40),(287,1,19,1.19,64),(288,1,19,1.19,91),(289,1,19,1.19,95),(290,1,19,1.19,104),(291,1,19,1.19,105),(292,1,19,1.19,113),(293,1,20,1.20,30),(294,1,20,1.20,31),(295,1,20,1.20,69),(296,1,20,1.20,69),(297,1,20,1.20,84),(298,1,20,1.20,90),(299,1,20,1.20,93),(300,1,20,1.20,123),(301,1,21,1.21,4),(302,1,21,1.21,9),(303,1,21,1.21,9),(304,1,21,1.21,12),(305,1,21,1.21,22),(306,1,21,1.21,51),(307,1,21,1.21,56),(308,1,21,1.21,59),(309,1,21,1.21,65),(310,1,21,1.21,67),(311,1,21,1.21,86),(312,1,21,1.21,92),(313,1,21,1.21,108),(314,1,21,1.21,128),(315,1,22,1.22,6),(316,1,22,1.22,22),(317,1,22,1.22,31),(318,1,22,1.22,41),(319,1,22,1.22,52),(320,1,22,1.22,62),(321,1,22,1.22,73),(322,1,22,1.22,74),(323,1,22,1.22,76),(324,1,22,1.22,95),(325,1,22,1.22,98),(326,1,22,1.22,100),(327,1,22,1.22,120),(328,1,22,1.22,124),(329,1,22,1.22,127),(330,1,22,1.22,131),(331,1,22,1.22,136),(332,1,22,1.22,144),(333,1,23,1.23,16),(334,1,23,1.23,21),(335,1,23,1.23,23),(336,1,23,1.23,36),(337,1,23,1.23,42),(338,1,23,1.23,46),(339,1,23,1.23,57),(340,1,23,1.23,62),(341,1,23,1.23,65),(342,1,23,1.23,65),(343,1,23,1.23,71),(344,1,23,1.23,73),(345,1,23,1.23,94),(346,1,23,1.23,119),(347,1,23,1.23,135),(348,1,23,1.23,140),(349,1,24,1.24,9),(350,1,24,1.24,21),(351,1,24,1.24,28),(352,1,24,1.24,41),(353,1,24,1.24,51),(354,1,24,1.24,59),(355,1,24,1.24,74),(356,1,24,1.24,83),(357,1,24,1.24,94),(358,1,24,1.24,103),(359,1,24,1.24,117),(360,1,24,1.24,123),(361,1,24,1.24,128),(362,1,24,1.24,129),(363,1,24,1.24,131),(364,1,24,1.24,139),(365,1,24,1.24,140),(366,1,24,1.24,151),(367,1,25,1.25,6),(368,1,25,1.25,13),(369,1,25,1.25,14),(370,1,25,1.25,23),(371,1,25,1.25,29),(372,1,25,1.25,51),(373,1,25,1.25,59),(374,1,25,1.25,62),(375,1,25,1.25,65),(376,1,25,1.25,96),(377,1,25,1.25,102),(378,1,25,1.25,113),(379,1,25,1.25,137),(380,1,25,1.25,139),(381,1,25,1.25,141),(382,1,25,1.25,144),(383,1,26,1.26,14),(384,1,26,1.26,15),(385,1,26,1.26,20),(386,1,26,1.26,24),(387,1,26,1.26,27),(388,1,26,1.26,57),(389,1,26,1.26,73),(390,1,26,1.26,87),(391,1,26,1.26,115),(392,1,27,1.27,10),(393,1,27,1.27,12),(394,1,27,1.27,12),(395,1,27,1.27,23),(396,1,27,1.27,31),(397,1,27,1.27,39),(398,1,27,1.27,72),(399,1,27,1.27,93),(400,1,27,1.27,130),(401,1,28,1.28,56),(402,1,28,1.28,59),(403,1,28,1.28,66),(404,1,28,1.28,104),(405,1,28,1.28,123),(406,1,8,1.08,34),(407,1,10,1.10,35);
/*!40000 ALTER TABLE `versi` ENABLE KEYS */;

--
-- Dumping routines for database 'u300618614_test'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-22 13:25:04
